CREATE TABLE Backend (id SERIAL PRIMARY KEY, name VARCHAR(100));
INSERT INTO Backend (name) VALUES ('Syeda Farwa Batool & Eman zai');
